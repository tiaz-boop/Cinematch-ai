// ============================================================
//  CineMatch AI — Main Application
//  Entry point: wires everything together
// ============================================================

import { searchMedia, getRecommendations, getTrending, posterSm } from './tmdb.js';
import { getAIMessage } from './ai.js';
import {
  createMessage,
  createTypingIndicator,
  createPosterThumb,
  createSearchResultItem
} from './components.js';

// ── App State ────────────────────────────────────────────────
const state = {
  watched: [],          // { id, type, title, poster, data }
  selectedSearchResult: null,
  searchDebounce: null,
  isThinking: false,
};

// ── DOM References ───────────────────────────────────────────
const $ = id => document.getElementById(id);
const chatArea      = $('chat-area');
const watchRow      = $('watch-row');
const addPosterBtn  = $('add-poster-btn');
const modal         = $('search-modal');
const modalSearch   = $('modal-search');
const searchResults = $('search-results');
const btnAdd        = $('btn-add');
const btnCancel     = $('btn-cancel');
const msgInput      = $('msg-input');
const sendBtn       = $('send-btn');
const landing       = $('landing');
const startBtn      = $('start-btn');

// ── Landing Screen ───────────────────────────────────────────
startBtn.addEventListener('click', () => {
  landing.classList.add('hidden');
  init();
});

// ── App Init ─────────────────────────────────────────────────
async function init() {
  // Pre-load 3 popular defaults into watch history
  const defaults = [
    { query: 'Inception 2010', type: 'movie' },
    { query: 'Parasite 2019', type: 'movie' },
    { query: 'Breaking Bad', type: 'tv' },
  ];

  for (const item of defaults) {
    try {
      const results = await searchMedia(item.query);
      if (results.length) {
        const m = results[0];
        addToWatched(m);
      }
    } catch (_) {}
  }

  // Greet the user
  appendBotMessage(
    "Hey!! 👋 So glad you're here! I'm CineMatch — your AI movie bestie. I've loaded some titles into your watch history already. Tap any poster for instant recs, or just tell me what vibe you're after. I know every film from every country and every era — from 1920s silent classics to 2024. Let's find your next obsession! 🎬",
    []
  );
}

// ── Watch History ─────────────────────────────────────────────
function addToWatched(movieData) {
  const title = movieData.title || movieData.name;
  if (state.watched.find(w => w.id === movieData.id)) return;

  const entry = {
    id: movieData.id,
    type: movieData.media_type || 'movie',
    title,
    poster: posterSm(movieData.poster_path),
    data: movieData,
  };

  state.watched.push(entry);
  renderWatchRow();
}

function removeFromWatched(id) {
  state.watched = state.watched.filter(w => w.id !== id);
  renderWatchRow();
}

function renderWatchRow() {
  watchRow.innerHTML = '';

  state.watched.forEach(movie => {
    const thumb = createPosterThumb(
      movie,
      id => removeFromWatched(id),
      m  => handlePosterClick(m)
    );
    watchRow.appendChild(thumb);
  });

  watchRow.appendChild(addPosterBtn);
}

// ── Poster Click → Instant Recs ──────────────────────────────
function handlePosterClick(movie) {
  sendMessage(`I loved "${movie.title}" — what should I watch next based on that?`, movie);
}

// ── Messaging ────────────────────────────────────────────────
function appendUserMessage(text) {
  const el = createMessage('user', text, [], () => {});
  chatArea.appendChild(el);
  scrollToBottom();
}

function appendBotMessage(text, recs) {
  const el = createMessage('bot', text, recs, text => sendMessage(text));
  chatArea.appendChild(el);
  scrollToBottom();
}

function showTyping() {
  const el = createTypingIndicator();
  chatArea.appendChild(el);
  scrollToBottom();
}

function hideTyping() {
  const el = $('typing-indicator');
  if (el) el.remove();
}

function scrollToBottom() {
  chatArea.scrollTop = chatArea.scrollHeight;
}

// ── Core Send Logic ───────────────────────────────────────────
async function sendMessage(text, movieObj = null) {
  if (!text.trim() || state.isThinking) return;
  state.isThinking = true;

  appendUserMessage(text);
  showTyping();

  let recs = [];

  try {
    if (movieObj) {
      // Recs based on a specific tapped poster
      recs = await getRecommendations(movieObj.id, movieObj.type);
    } else if (state.watched.length) {
      // Recs based on most recently added watched title
      const last = state.watched[state.watched.length - 1];
      recs = await getRecommendations(last.id, last.type);
      // Filter out already-watched
      const watchedIds = new Set(state.watched.map(w => w.id));
      recs = recs.filter(r => !watchedIds.has(r.id));
    } else {
      // Trending fallback for new users
      recs = await getTrending();
    }
  } catch (err) {
    console.warn('TMDB fetch error:', err.message);
  }

  // Get AI-generated friend message
  const watchedTitles = state.watched.map(w => w.title);
  const aiText = await getAIMessage(text, watchedTitles, recs);

  hideTyping();
  appendBotMessage(aiText, recs.slice(0, 4));
  state.isThinking = false;
}

// ── Input Handlers ────────────────────────────────────────────
sendBtn.addEventListener('click', () => {
  const text = msgInput.value.trim();
  if (!text) return;
  msgInput.value = '';
  autoResizeTextarea(msgInput);
  sendMessage(text);
});

msgInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendBtn.click();
  }
});

msgInput.addEventListener('input', () => autoResizeTextarea(msgInput));

function autoResizeTextarea(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 100) + 'px';
}

// ── Search Modal ──────────────────────────────────────────────
addPosterBtn.addEventListener('click', openModal);
btnCancel.addEventListener('click', closeModal);
btnAdd.addEventListener('click', confirmAdd);

function openModal() {
  state.selectedSearchResult = null;
  modalSearch.value = '';
  searchResults.innerHTML = '<div class="search-status">Type to search any movie or TV series...</div>';
  btnAdd.disabled = true;
  modal.classList.add('open');
  setTimeout(() => modalSearch.focus(), 80);
}

function closeModal() {
  modal.classList.remove('open');
  state.selectedSearchResult = null;
}

modalSearch.addEventListener('input', e => {
  clearTimeout(state.searchDebounce);
  const val = e.target.value.trim();
  if (!val) {
    searchResults.innerHTML = '<div class="search-status">Type to search...</div>';
    return;
  }
  searchResults.innerHTML = '<div class="search-status">Searching...</div>';
  state.searchDebounce = setTimeout(() => doSearch(val), 380);
});

async function doSearch(query) {
  try {
    const results = await searchMedia(query);
    searchResults.innerHTML = '';

    if (!results.length) {
      searchResults.innerHTML = '<div class="search-status">No results — try a different title</div>';
      return;
    }

    results.forEach(m => {
      const item = createSearchResultItem(m, selected => {
        state.selectedSearchResult = selected;
        btnAdd.disabled = false;
      });
      searchResults.appendChild(item);
    });
  } catch (err) {
    searchResults.innerHTML = '<div class="search-status">Search failed. Check your TMDB API key.</div>';
  }
}

async function confirmAdd() {
  if (!state.selectedSearchResult) return;
  const m = state.selectedSearchResult;
  addToWatched(m);
  closeModal();
  setTimeout(() => {
    sendMessage(
      `I just finished "${m.title || m.name}" — what should I watch next based on that?`,
      { id: m.id, type: m.media_type || 'movie' }
    );
  }, 350);
}

// Close modal on backdrop click
modal.addEventListener('click', e => {
  if (e.target === modal) closeModal();
});
