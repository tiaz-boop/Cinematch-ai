// ============================================================
//  CineMatch AI — UI Components
//  Pure JS DOM builders for all UI elements
// ============================================================

import { posterLg, ratingStars } from './tmdb.js';

// ── Message bubble ──────────────────────────────────────────
export function createMessage(role, text, recs = [], onQuickReply) {
  const wrap = document.createElement('div');
  wrap.className = `message ${role}`;

  const av = document.createElement('div');
  av.className = `message-avatar ${role}`;
  av.textContent = role === 'user' ? 'ME' : '🎬';

  const bub = document.createElement('div');
  bub.className = `bubble ${role}`;

  if (role === 'bot') {
    const badge = document.createElement('div');
    badge.className = 'ai-badge';
    badge.textContent = '✦ AI-powered';
    bub.appendChild(badge);
  }

  const textNode = document.createElement('div');
  textNode.style.whiteSpace = 'pre-wrap';
  textNode.textContent = text;
  bub.appendChild(textNode);

  if (recs.length) {
    bub.appendChild(createRecGrid(recs, onQuickReply));
    bub.appendChild(createQuickBtns([
      'More like these',
      'Something older',
      'From a different country',
      'Surprise me 🎲',
    ], onQuickReply));
  }

  wrap.appendChild(av);
  wrap.appendChild(bub);
  return wrap;
}

// ── Recommendation card grid ─────────────────────────────────
function createRecGrid(recs, onCardClick) {
  const grid = document.createElement('div');
  grid.className = 'rec-grid';

  recs.forEach(m => {
    const title  = m.title || m.name;
    const year   = (m.release_date || m.first_air_date || '').slice(0, 4);
    const poster = posterLg(m.poster_path);
    const lang   = m.original_language && m.original_language !== 'en'
                    ? ' · ' + m.original_language.toUpperCase() : '';
    const { score, stars } = m.vote_average ? ratingStars(m.vote_average) : { score: null, stars: '' };

    const card = document.createElement('div');
    card.className = 'rec-card';

    if (poster) {
      const img = document.createElement('img');
      img.className = 'rec-card-poster';
      img.src = poster;
      img.alt = title;
      img.loading = 'lazy';
      card.appendChild(img);
    } else {
      const ph = document.createElement('div');
      ph.className = 'rec-card-noposter';
      ph.textContent = '🎬';
      card.appendChild(ph);
    }

    const body = document.createElement('div');
    body.className = 'rec-card-body';
    body.innerHTML = `
      <div class="rec-card-title">${title}</div>
      <div class="rec-card-meta">${year}${lang}</div>
      ${score ? `<div class="rec-card-rating"><span class="stars">${stars}</span><span class="match-score">${score}/5</span></div>` : ''}
      ${m.overview ? `<div class="rec-card-overview">${m.overview}</div>` : ''}
    `;
    card.appendChild(body);
    card.addEventListener('click', () => onCardClick(`Tell me everything about "${title}" (${year}) — why should I watch it?`));

    grid.appendChild(card);
  });

  return grid;
}

// ── Quick reply buttons ──────────────────────────────────────
export function createQuickBtns(labels, onClick) {
  const wrap = document.createElement('div');
  wrap.className = 'quick-btns';
  labels.forEach(label => {
    const btn = document.createElement('div');
    btn.className = 'quick-btn';
    btn.textContent = label;
    btn.addEventListener('click', () => onClick(label));
    wrap.appendChild(btn);
  });
  return wrap;
}

// ── Typing indicator ─────────────────────────────────────────
export function createTypingIndicator() {
  const wrap = document.createElement('div');
  wrap.className = 'message bot';
  wrap.id = 'typing-indicator';

  const av = document.createElement('div');
  av.className = 'message-avatar bot';
  av.textContent = '🎬';

  const bub = document.createElement('div');
  bub.className = 'bubble bot';

  const dots = document.createElement('div');
  dots.className = 'typing-dots';
  for (let i = 0; i < 3; i++) {
    const d = document.createElement('div');
    d.className = 'typing-dot';
    dots.appendChild(d);
  }
  bub.appendChild(dots);
  wrap.appendChild(av);
  wrap.appendChild(bub);
  return wrap;
}

// ── Poster thumbnail in watch bar ────────────────────────────
export function createPosterThumb(movie, onRemove, onClick) {
  const wrap = document.createElement('div');
  wrap.className = 'poster-thumb';
  wrap.title = movie.title;

  if (movie.poster) {
    const img = document.createElement('img');
    img.src = movie.poster;
    img.alt = movie.title;
    img.loading = 'lazy';
    img.onerror = () => { img.replaceWith(makePlaceholder()); };
    wrap.appendChild(img);
  } else {
    wrap.appendChild(makePlaceholder());
  }

  const removeBtn = document.createElement('div');
  removeBtn.className = 'poster-remove';
  removeBtn.textContent = '×';
  removeBtn.addEventListener('click', e => { e.stopPropagation(); onRemove(movie.id); });
  wrap.appendChild(removeBtn);

  const titleEl = document.createElement('div');
  titleEl.className = 'poster-title';
  titleEl.textContent = movie.title;
  wrap.appendChild(titleEl);

  wrap.addEventListener('click', () => onClick(movie));
  return wrap;
}

function makePlaceholder() {
  const ph = document.createElement('div');
  ph.className = 'poster-placeholder';
  ph.textContent = '🎬';
  return ph;
}

// ── Search result item in modal ──────────────────────────────
export function createSearchResultItem(movie, onSelect) {
  const title = movie.title || movie.name;
  const year  = (movie.release_date || movie.first_air_date || '').slice(0, 4);
  const poster = movie.poster_path
    ? 'https://image.tmdb.org/t/p/w200' + movie.poster_path : null;

  const item = document.createElement('div');
  item.className = 'search-result-item';

  if (poster) {
    const img = document.createElement('img');
    img.src = poster;
    img.alt = title;
    item.appendChild(img);
  } else {
    const ph = document.createElement('div');
    ph.className = 'search-result-noposter';
    ph.textContent = '🎬';
    item.appendChild(ph);
  }

  const titleEl = document.createElement('div');
  titleEl.className = 'search-result-title';
  titleEl.textContent = `${title}${year ? ' (' + year + ')' : ''}`;
  item.appendChild(titleEl);

  item.addEventListener('click', () => {
    document.querySelectorAll('.search-result-item').forEach(el => el.classList.remove('selected'));
    item.classList.add('selected');
    onSelect(movie);
  });

  return item;
}
