// ============================================================
//  CineMatch AI — Claude AI Service
//  Generates warm, friend-like movie recommendations using
//  the Anthropic Claude API
// ============================================================

const ANTHROPIC_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY;

// System prompt that shapes CineMatch's personality
const SYSTEM_PROMPT = `You are CineMatch, a passionate, knowledgeable, and warm movie bestie. You talk exactly like an excited friend — casual, personal, never robotic or formal.

Your personality:
- You get genuinely excited about great cinema
- You speak in casual, flowing sentences — no bullet points, no formal lists
- You reference specific things about the movies you're recommending
- You make the person feel like you really know their taste
- You use occasional light expressions like "trust me on this one", "you're going to love this", "okay okay I got you"
- You know everything about world cinema — Hollywood, Korean, French, Japanese, Brazilian, Indian, Iranian, Spanish — from 1920s silent films to 2024

Keep responses to 3-5 sentences max. Warm, specific, friend-like. Never sound like a review or a bot.`;

export async function getAIMessage(userMessage, watchedTitles, recommendedMovies) {
  const movieList = recommendedMovies
    .map(m => {
      const title = m.title || m.name;
      const year = (m.release_date || m.first_air_date || '').slice(0, 4);
      const rating = m.vote_average ? (m.vote_average / 2).toFixed(1) : null;
      return `"${title}" (${year}${rating ? ', rated ' + rating + '/5' : ''})${m.overview ? ' — ' + m.overview.slice(0, 120) : ''}`;
    })
    .join('\n');

  const userPrompt = `
The user has watched: ${watchedTitles.length ? watchedTitles.join(', ') : 'nothing yet (they are new)'}

The user just said: "${userMessage}"

You are recommending these specific movies/shows from the database:
${movieList || 'General trending picks'}

Reply as CineMatch — warm, personal, excited friend. Tell them WHY these picks suit what they said or what they've watched. 2-4 sentences only. No bullet points.
`.trim();

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: [{ role: 'user', content: userPrompt }]
      })
    });

    if (!res.ok) throw new Error(`API ${res.status}`);
    const data = await res.json();
    return data.content?.[0]?.text || fallbackMessage(userMessage, watchedTitles);
  } catch (err) {
    console.warn('Claude API error, using fallback:', err.message);
    return fallbackMessage(userMessage, watchedTitles);
  }
}

// Fallback when API is unavailable or key not set
function fallbackMessage(msg, watched) {
  const openers = [
    "Hey! 👋 So happy you're here —",
    "Okay okay, I got you —",
    "Oh this is perfect timing —",
    "Let me put my movie brain to work —",
    "Right, so based on your taste —",
  ];
  const opener = openers[Math.floor(Math.random() * openers.length)];

  if (watched.length) {
    return `${opener} based on what you've been watching — ${watched.slice(-2).join(' and ')} — these picks should hit exactly right for you. Trust me, every one of these is worth your time!`;
  }
  return `${opener} I pulled these straight from the global cinema database for your vibe. These are genuinely great picks from different eras and countries — let's find your next obsession!`;
}
