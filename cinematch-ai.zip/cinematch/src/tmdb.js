// ============================================================
//  CineMatch AI — TMDB API Service
//  Handles all communication with The Movie Database API
// ============================================================

const API_KEY  = import.meta.env.VITE_TMDB_API_KEY;
const BASE_URL = 'https://api.themoviedb.org/3';
const IMG_SM   = 'https://image.tmdb.org/t/p/w200';
const IMG_MD   = 'https://image.tmdb.org/t/p/w342';
const IMG_LG   = 'https://image.tmdb.org/t/p/w500';

async function tmdbFetch(endpoint, params = {}) {
  const url = new URL(`${BASE_URL}${endpoint}`);
  url.searchParams.set('api_key', API_KEY);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url.toString());
  if (!res.ok) throw new Error(`TMDB ${res.status}: ${endpoint}`);
  return res.json();
}

// Search movies + TV shows
export async function searchMedia(query) {
  const data = await tmdbFetch('/search/multi', { query, include_adult: false });
  return (data.results || [])
    .filter(m => (m.media_type === 'movie' || m.media_type === 'tv') && m.poster_path)
    .slice(0, 9);
}

// Get TMDB-powered recommendations for a given title
export async function getRecommendations(id, type) {
  const [recData, simData] = await Promise.all([
    tmdbFetch(`/${type}/${id}/recommendations`),
    tmdbFetch(`/${type}/${id}/similar`)
  ]);
  const seen = new Set();
  const merged = [];
  [...(recData.results || []), ...(simData.results || [])].forEach(m => {
    if (!seen.has(m.id) && m.poster_path) { seen.add(m.id); merged.push(m); }
  });
  return merged.slice(0, 4);
}

// Get trending titles (used when no watch history yet)
export async function getTrending() {
  const data = await tmdbFetch('/trending/all/week');
  return (data.results || []).filter(m => m.poster_path).slice(0, 4);
}

// Get full details for a movie or show
export async function getDetails(id, type) {
  return tmdbFetch(`/${type}/${id}`, { append_to_response: 'credits,keywords' });
}

// Poster URL helpers
export const posterSm = path => path ? IMG_SM + path : null;
export const posterMd = path => path ? IMG_MD + path : null;
export const posterLg = path => path ? IMG_LG + path : null;

// Helper: human readable rating out of 5
export const ratingStars = vote => {
  const out5 = Math.round((vote / 2) * 10) / 10;
  const full = Math.round(out5);
  return { score: out5.toFixed(1), stars: '★'.repeat(full) + '☆'.repeat(5 - full) };
};
