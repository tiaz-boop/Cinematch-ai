# 🎬 CineMatch AI

Your personal AI movie bestie — powered by Claude AI + TMDB.

Real movie posters · Friend-like AI chat · Every film from every country & era

---

## ✨ Features

- **Real movie poster thumbnails** from TMDB (50M+ titles)
- **Claude AI** generates warm, personal friend-style responses
- **Global cinema** — Hollywood, Korean, Japanese, French, Brazilian & more
- **Tap a poster** → instant recommendations
- **Search any title** ever made and add it to your watch history
- **Beautiful dark UI** with cinematic vibes
- **Free to run** with your own API keys

---

## 🚀 Quick Start (Local)

### Step 1 — Get your FREE API keys

**TMDB (Movie Database) — completely free:**
1. Go to https://www.themoviedb.org/signup
2. Verify your email
3. Go to https://www.themoviedb.org/settings/api
4. Click "Create" → choose "Developer" → fill the form
5. Copy your **API Key (v3 auth)**

**Anthropic Claude API — free credits on signup:**
1. Go to https://console.anthropic.com
2. Create account
3. Go to https://console.anthropic.com/keys
4. Click "Create Key"
5. Copy the key (starts with `sk-ant-...`)

---

### Step 2 — Set up the project

```bash
# Clone or download the project folder
cd cinematch

# Install dependencies (just Vite)
npm install

# Copy the env example
cp .env.example .env
```

Open `.env` and paste your keys:
```
VITE_TMDB_API_KEY=paste_your_tmdb_key_here
VITE_ANTHROPIC_API_KEY=paste_your_claude_key_here
```

---

### Step 3 — Run it

```bash
npm run dev
```

Open http://localhost:3000 — you're live! 🎉

---

## 🌐 Deploy to the Web (FREE — Vercel)

### Option A — GitHub + Vercel (recommended)

1. Push this folder to a GitHub repository
2. Go to https://vercel.com and sign up (free)
3. Click "New Project" → import your GitHub repo
4. In **Environment Variables**, add:
   - `VITE_TMDB_API_KEY` = your TMDB key
   - `VITE_ANTHROPIC_API_KEY` = your Claude key
5. Click **Deploy**

Your app is live at `https://your-project.vercel.app` in ~2 minutes! ✅

### Option B — Netlify (also free)

1. Go to https://netlify.com
2. Drag and drop the `dist` folder (after running `npm run build`)
3. Add environment variables in Site Settings → Environment Variables

---

## 💰 How to Make Money (all free to set up)

### 1. Google AdSense — Passive income
- Sign up: https://adsense.google.com
- Add one `<script>` snippet to `index.html`
- Earn $20–$80 per 10,000 visitors/month automatically

### 2. Affiliate Links — Per signup income
Add to each movie card a link to streaming platforms:
- **Amazon Associates**: https://affiliate-program.amazon.com
- **Apple Affiliate**: https://affiliate.apple.com
- Earn $3–$15 per new subscriber who clicks your link

### 3. "Pro" version — Gumroad (free to list)
- https://gumroad.com — 0% monthly fee, 10% only on sales
- Offer $3/month for: no ads, unlimited history, export watchlist

### 4. Donations — Ko-fi
- https://ko-fi.com — free, add a small button to your app
- Movie fans are generous!

---

## 📁 File Structure

```
cinematch/
├── index.html          ← Main HTML (all DOM elements)
├── package.json        ← Project config
├── vite.config.js      ← Build tool config
├── .env.example        ← API key template (copy to .env)
└── src/
    ├── style.css       ← Complete dark cinematic stylesheet
    ├── main.js         ← App logic & event handling
    ├── tmdb.js         ← TMDB API service (posters, search, recs)
    ├── ai.js           ← Claude AI service (friend-like responses)
    └── components.js   ← DOM builders (messages, cards, modals)
```

---

## 🛠 Customization

### Change the default preloaded movies
In `src/main.js`, edit the `defaults` array in the `init()` function:
```js
const defaults = [
  { query: 'The Godfather 1972' },
  { query: 'Spirited Away' },
  { query: 'Squid Game' },
];
```

### Change the AI personality
In `src/ai.js`, edit the `SYSTEM_PROMPT` string to change how CineMatch talks.

### Change colors
In `src/style.css`, edit the `:root` CSS variables at the top of the file.

---

## 🔑 API Costs

| Service | Free Tier | Paid |
|---------|-----------|------|
| TMDB    | Unlimited free forever | — |
| Claude API | ~$5 free credits | ~$0.003 per conversation |
| Vercel  | 100GB bandwidth/month free | — |

At 1,000 users/day Claude costs ~$3/day — easily covered by AdSense revenue.

---

## 📞 Support

Built with ❤️ using Claude AI (Anthropic) + TMDB API.

- TMDB docs: https://developers.themoviedb.org
- Claude API docs: https://docs.anthropic.com
- Vite docs: https://vitejs.dev
